package dao;
import util.*;
import Model.*;
import myexceptions.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransportManagementServiceImpl implements TransportManagementService 
{

	Connection con;
	
	public TransportManagementServiceImpl()
	{
	con = DBConnUtil.getConnection();
	}

	@Override
	public boolean addVehicle(Vehicle vehicle) 
	{
	    try {
	         PreparedStatement stat=con.prepareStatement("insert into Vehicles(Model, Capacity, Type, Status)values(?, ?, ?, ?)");
	        stat.setString(1,vehicle.getModel());
	        stat.setDouble(2,vehicle.getCapacity());
	        stat.setString(3,vehicle.getType());
	        stat.setString(4,vehicle.getStatus());
	        if(stat.executeUpdate()>0) 
	        {
	        	System.out.println("Vehicle ADDED Successfully !");
	        	return true;
	        }
	    } 
	         catch(Exception e) 
	    {
	        System.out.println(e.getMessage());
	        return false;
	    }
		return false;
	}
 
	@Override
	public boolean updateVehicle(Vehicle vehicle) throws VehicleNotFoundException 
	{
	    try
	    {
	        PreparedStatement stat=con.prepareStatement("select * from Vehicles where VehicleID=?");
	        stat.setInt(1,vehicle.getVehicleID());
	        ResultSet rs=stat.executeQuery();	        
	        if(!rs.next()) 
	        {	            
	            throw new VehicleNotFoundException("VehicleID "+vehicle.getVehicleID()+" cannot be found in DB !");
	        }
	        PreparedStatement stat1=con.prepareStatement("update Vehicles set Model=?, Capacity=?, Type=?, Status=? where VehicleID=?");
	        stat1.setString(1,vehicle.getModel());
	        stat1.setDouble(2,vehicle.getCapacity());
	        stat1.setString(3,vehicle.getType());
	        stat1.setString(4,vehicle.getStatus());
	        stat1.setInt(5,vehicle.getVehicleID());
	        if(stat1.executeUpdate()>0) 
	        {
	            System.out.println("Vehicle UPDATED Successfully !");
	            return true;
	        }
	    } 
	    catch(SQLException e)
	    {
	        System.out.println(e.getMessage());
	        return false;
	    }
	    return false;
	}

	@Override
	public boolean deleteVehicle(int vehicleId) throws VehicleNotFoundException
	{
	    try
	    {
	        PreparedStatement stat=con.prepareStatement("select * from Vehicles where VehicleID=?");
	        stat.setInt(1,vehicleId);
	        ResultSet rs=stat.executeQuery();
	        if(!rs.next())
	        {
	            
	            throw new VehicleNotFoundException("VehicleID "+vehicleId+" cannot be found in DB !");
	        }
	        PreparedStatement stat1=con.prepareStatement("delete from Vehicles where VehicleID=?");
	        stat1.setInt(1,vehicleId);
	        if(stat1.executeUpdate()>0)
	        {
	            System.out.println("Vehicle DELETED successfully !");
	            return true;
	        }
	    }
	    catch(SQLException e)
	    {
	        System.out.println(e.getMessage());
	        return false;
	    }
	    return false;
	}

    @Override
    public boolean scheduleTrip(int vehicleId, int routeId, String departureDate, String arrivalDate)
    {
        try{
        	PreparedStatement stat=con.prepareStatement("select * from Vehicles where VehicleID=?");
	        stat.setInt(1,vehicleId);
	        ResultSet rs=stat.executeQuery();
	        if(!rs.next()) 
	        {
	            System.out.println("VehicleID "+vehicleId+" cannot be found in DB !");
	            return false;
	        }
	        PreparedStatement statt=con.prepareStatement("select * from Routes where RouteID=?");
	        statt.setInt(1,routeId);
	        ResultSet rss=statt.executeQuery();
	        if(!rss.next()) 
	        {
	            System.out.println("RouteID "+routeId+" cannot be found in DB !");
	            return false;
	        }
        	PreparedStatement stat1=con.prepareStatement("insert into Trips(VehicleID, RouteID, DepartureDate, ArrivalDate, Status, TripType, MaxPassengers) values(?, ?, ?, ?, 'Scheduled', 'Passenger', 50)");
            stat1.setInt(1,vehicleId);
            stat1.setInt(2,routeId);
            stat1.setString(3,departureDate);
            stat1.setString(4,arrivalDate);
           if(stat1.executeUpdate()>0)
           {
        	   System.out.println("Trip SCHEDULED successfully !");
   	        return true;
           }
        } 
        catch(Exception e) 
        {
            System.out.println(e.getMessage());
            return false;
        }
        return false;
    }

    @Override
    public boolean cancelTrip(int tripId) 
    {
        try {
            PreparedStatement stat=con.prepareStatement("select * from Trips where TripID=?");
            stat.setInt(1,tripId);
            ResultSet rs=stat.executeQuery();
            if(!rs.next()) 
            {
                System.out.println("TripID "+tripId+" cannot be found in DB !");
                return false;
            }
            PreparedStatement stat1 = con.prepareStatement("update Trips set Status='Cancelled' where TripID=?");
            stat1.setInt(1, tripId);
            if(stat1.executeUpdate()>0)
            {
            	System.out.println("Trip CANCELLED successfully !");
    	        return true;
            }
        } 
        catch(Exception e) 
        {
            System.out.println( e.getMessage());
            return false;
        }
        return false;
    }

    @Override
    public boolean bookTrip(int tripId, int passengerId, String bookingDate)
    {
        try {
            PreparedStatement stat=con.prepareStatement("select * from Trips where TripID=?");
           stat.setInt(1,tripId);
            ResultSet rs=stat.executeQuery();
            if(!rs.next())
            {
                System.out.println("TripID "+tripId+" cannot be found in DB !");
                return false;
            }
            PreparedStatement statt=con.prepareStatement("select * from Passengers where PassengerID=?");
             statt.setInt(1,passengerId);
             ResultSet rss=statt.executeQuery();
             if(!rss.next())
             {
                 System.out.println("PassengerID "+passengerId+" cannot be found in DB !");
                 return false;
             }
            PreparedStatement stat1=con.prepareStatement("insert into Bookings(TripID, PassengerID, BookingDate, Status)values(?, ?, ?, 'Booked')");
            stat1.setInt(1,tripId);
            stat1.setInt(2,passengerId);
            stat1.setString(3,bookingDate);
            if(stat1.executeUpdate()>0)
            {
            	System.out.println("Trip BOOKED successfully !");
    	        return true;
            }
        } 
        catch(Exception e) 
        {
            System.out.println(e.getMessage());
            return false;
        }
        return false;
    }

    @Override
    public boolean cancelBooking(int bookingId) throws BookingNotFoundException
    {
        try {
            PreparedStatement stat=con.prepareStatement("select * from Bookings where BookingID=?");
            stat.setInt(1,bookingId);
            ResultSet rs=stat.executeQuery();
            if(!rs.next()) 
            {
                throw new BookingNotFoundException("BookingID "+bookingId+" Cannot be found in DB !");
            }
            PreparedStatement stat1=con.prepareStatement("update Bookings set Status='Cancelled' where BookingID=?");
            stat1.setInt(1,bookingId);
            if(stat1.executeUpdate()>0)
            {
            	System.out.println("Booking CANCELLED successfully !");
            	return true;
            }
        }
        catch(SQLException e)
        {
            System.out.println(e.getMessage());
            return false;
        }
        return false;
    }


    @Override
    public boolean allocateDriver(int driverId, int tripId) 
    {
        try {
            PreparedStatement stat=con.prepareStatement("select * from Trips where TripID=?");
            stat.setInt(1,tripId);
            ResultSet rs1=stat.executeQuery();
            if(!rs1.next())
            {
                System.out.println("TripID "+tripId+" cannot be found in DB !");
                return false;
            }
            PreparedStatement stat1=con.prepareStatement("select * from Driver where DriverID=?");
            stat1.setInt(1,driverId);
            ResultSet rs2=stat1.executeQuery();
            if(rs2.next())
            {
                PreparedStatement stat2=con.prepareStatement("update Driver set TripID=? where DriverID=?");
                stat2.setInt(1,tripId);
                stat2.setInt(2,driverId);
                if(stat2.executeUpdate()>0) 
                {
                	System.out.println("Driver ALLOCATED successfully !");
                	return true;
                }
               
            } 
            else 
            {
                PreparedStatement stat3=con.prepareStatement("insert into Driver(DriverID, TripID)values(?,?)");
                stat3.setInt(1,driverId);
                stat3.setInt(2,tripId);
                if(stat3.executeUpdate()>0)
                {
                	System.out.println("Driver ALLOCATED successfully !");
                	return true;
                }
               
            }
            return false;

        } 
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return false;
        }
        
    }

    @Override
    public boolean deallocateDriver(int tripId) 
    {
        try
        {
            PreparedStatement stat=con.prepareStatement("select * from Driver WHERE TripID=?");
            stat.setInt(1,tripId);
            ResultSet rs=stat.executeQuery();
            if(!rs.next()) 
            {
                System.out.println("TripID "+tripId+" cannot be found in DB !");
                return false;
            }
            PreparedStatement stat1=con.prepareStatement("update Driver set TripID=null where TripID=?");
            stat1.setInt(1,tripId);
            if (stat1.executeUpdate()>0) 
            {
                System.out.println("Driver DEALLOCATED successfully !");
                return true;
            }

        } 
        catch(Exception e) 
        {
            System.out.println(e.getMessage());
            return false;
        }
        return false;
    }

    @Override
    public List<Booking> getBookingsByPassenger(int passengerId) 
    {
        List<Booking> bookings= new ArrayList<>();
        try
        {
            PreparedStatement stat=con.prepareStatement("select * from Bookings where PassengerID=?");
            stat.setInt(1,passengerId);
            ResultSet rs=stat.executeQuery();
            if(!rs.next()) 
            {
                System.out.println("PassengerID "+passengerId+" cannot be found in DB !");
            }
            PreparedStatement stat1=con.prepareStatement("select * from Bookings where PassengerID=?");
            stat1.setInt(1,passengerId);
            ResultSet rs1=stat1.executeQuery();
            while(rs1.next()) 
            {
                Booking b= new Booking();
                b.setBookingID(rs1.getInt("BookingID"));
                b.setTripID(rs1.getInt("TripID"));
                b.setPassengerID(rs1.getInt("PassengerID"));
                b.setBookingDate(rs1.getString("BookingDate"));
                b.setStatus(rs1.getString("Status"));
                bookings.add(b);
            }
        } 
        catch(SQLException e) 
        {
            System.out.println(e.getMessage());
        }
        return bookings;
    }
    
    @Override
    public List<Booking> getBookingsByTrip(int tripId) 
    {
        List<Booking> bookings=new ArrayList<>();
        try 
        {
            PreparedStatement stat=con.prepareStatement("select * from Bookings where TripID=?");
            stat.setInt(1,tripId);
            ResultSet rs= stat.executeQuery();
            while (rs.next()) {
                Booking b = new Booking();
                b.setBookingID(rs.getInt("BookingID"));
                b.setTripID(rs.getInt("TripID"));
                b.setPassengerID(rs.getInt("PassengerID"));
                b.setBookingDate(rs.getString("BookingDate"));
                b.setStatus(rs.getString("Status"));
                bookings.add(b);
            }

        } 
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return bookings;
    }

    @Override
    public List<Drivers> getAvailableDrivers() 
    {
        List<Drivers> drivers= new ArrayList<>();
        try {
             PreparedStatement stat=con.prepareStatement("select * from Driver where TripID IS NULL");
             ResultSet rs=stat.executeQuery();
            while(rs.next())
            {
                Drivers d=new Drivers();
                d.setDriverID(rs.getInt("DriverID"));       
                drivers.add(d);
            }

        } 
        catch(Exception e) 
        {
            System.out.println(e.getMessage());
        }
        return drivers;
    }

	
	
}
