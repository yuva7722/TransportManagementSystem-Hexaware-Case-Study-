package dao;

import Model.*;

import myexceptions.*;

import java.util.List;

public interface TransportManagementService {

    boolean addVehicle(Vehicle vehicle);

    boolean updateVehicle(Vehicle vehicle) throws VehicleNotFoundException;

    boolean deleteVehicle(int vehicleId) throws VehicleNotFoundException;

    boolean scheduleTrip(int vehicleId, int routeId, String departureDate, String arrivalDate);

    boolean cancelTrip(int tripId);

    boolean bookTrip(int tripId, int passengerId, String bookingDate);

    boolean cancelBooking(int bookingId) throws BookingNotFoundException;

    boolean allocateDriver(int tripId, int driverId);

    boolean deallocateDriver(int tripId);

    List<Booking> getBookingsByPassenger(int passengerId);

    List<Booking> getBookingsByTrip(int tripId);

    List<Drivers> getAvailableDrivers();
}
