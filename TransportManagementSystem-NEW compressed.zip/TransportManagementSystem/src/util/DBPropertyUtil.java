package util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil
{

    public static Properties loadProperties(String fPath) throws Exception
    {
        Properties p= new Properties();
        try (InputStream input=new FileInputStream(fPath)) 
        {
            p.load(input);
        }
        return p;
    }
}