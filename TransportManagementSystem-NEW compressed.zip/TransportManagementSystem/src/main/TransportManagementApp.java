package main;

import dao.TransportManagementService;
import dao.TransportManagementServiceImpl;
import myexceptions.BookingNotFoundException;
import myexceptions.VehicleNotFoundException;
import java.util.List;
import java.util.Scanner;
import Model.*;

public class TransportManagementApp 
{

    public static void main(String[] args) throws VehicleNotFoundException, BookingNotFoundException {
        Scanner sc = new Scanner(System.in);
        TransportManagementService ser=new TransportManagementServiceImpl();
        int c;
        do {
        	System.out.println("***-------------------------------------------***");
            System.out.println("\nTransport Management Menu");
            System.out.println("1. Add Vehicle");
            System.out.println("2. Update Vehicle");
            System.out.println("3. Delete Vehicle");
            System.out.println("4. Schedule Trip");
            System.out.println("5. Cancel Trip");
            System.out.println("6. Book Trip");
            System.out.println("7. Cancel Booking");
            System.out.println("8. Allocate Driver");
            System.out.println("9. Deallocate Driver");
            System.out.println("10. Get Bookings by Passenger");
            System.out.println("11. Get Bookings by Trip");
            System.out.println("12. Get Available Drivers");
            System.out.println("13. Exit");
        	System.out.println("***-------------------------------------------***");
            System.out.print("Enter your choice: ");
            c=sc.nextInt();
            sc.nextLine();
            switch(c)
            {
                case 1:
                	System.out.println("You have decided to ADD VEHICLE! ");
                    System.out.print("Enter Model: ");
                    String model=sc.nextLine();
                    System.out.print("Enter Capacity: ");
                    double capacity=sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Enter Type(Truck or Van or Bus): ");
                    String type=sc.nextLine();
                    System.out.print("Enter Status(Available or Maintenance): ");
                    String status=sc.nextLine();
                    ser.addVehicle(new Vehicle(model, capacity, type, status));
                   break;

                case 2:
                    System.out.println("You have decided to UPDATE VEHICLE! ");
                    try
                    {
                        System.out.print("Enter Vehicle ID to Update: ");
                        int updateVId=sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter New Model: ");
                        String newModel=sc.nextLine();
                        System.out.print("Enter New Capacity: ");
                        double newCapacity=sc.nextDouble();
                        sc.nextLine();
                        System.out.print("Enter New Type (Truck or Van or Bus): ");
                        String newType=sc.nextLine();
                        System.out.print("Enter New Status (Available or Maintenance): ");
                        String newStatus=sc.nextLine();

                        boolean f=ser.updateVehicle(new Vehicle(updateVId, newModel, newCapacity, newType, newStatus));
                        if(!f) 
                        {
                            System.out.println("Vehicle update failed.");
                        }
                    }
                    catch(VehicleNotFoundException e) 
                    {
                        System.out.println(e.getMessage());
                    }
                    catch(Exception e) 
                    {
                        System.out.println(e.getMessage());
                    }
                    break;
         
                case 3:
                	
                    System.out.println("You have decided to DELETE VEHICLE! ");
                    try {
                        System.out.print("Enter Vehicle ID to Delete: ");
                        int deleteVId = sc.nextInt();
                        sc.nextLine();
                        boolean f= ser.deleteVehicle(deleteVId);
                        if(!f) 
                        {
                            System.out.println("Vehicle deletion failed.");
                        }
                    } 
                    catch(VehicleNotFoundException e) 
                    {
                        System.out.println(e.getMessage());
                    } 
                    catch (Exception e)
                    {
                        System.out.println(e.getMessage());
                    }
                    break;


                case 4:
                	System.out.println("You have decided to SCHEDULE TRIP! ");
                    System.out.print("Enter Vehicle ID: ");
                    int vehicleId=sc.nextInt();
                    System.out.print("Enter Route ID: ");
                    int routeId=sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Departure Date in format(YYYY-MM-DD HH:MM:SS): ");
                    String departureDate= sc.nextLine();
                    System.out.print("Enter Arrival Date in format(YYYY-MM-DD HH:MM:SS): ");
                    String arrivalDate=sc.nextLine();
                    ser.scheduleTrip(vehicleId, routeId, departureDate, arrivalDate);
                    break;

                case 5:
                	System.out.println("You have decided to CANCEL TRIP! ");
                    System.out.print("Enter Trip ID to Cancel: ");
                    int CTripId =sc.nextInt();
                    ser.cancelTrip(CTripId);
                    break;

                case 6:
                	System.out.println("You have decided to BOOK TRIP! ");
                    System.out.print("Enter Trip ID: ");
                    int BTripId= sc.nextInt();
                    System.out.print("Enter Passenger ID: ");
                    int BpassengerId=sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Booking Date (YYYY-MM-DD hh:mm:ss): ");
                    String bookingDate= sc.nextLine();
                    ser.bookTrip(BTripId, BpassengerId, bookingDate);
                    break;

                case 7:
                    System.out.println("You have decided to CANCEL Booking! ");
                    try
                    {
                        System.out.print("Enter Booking ID to Cancel: ");
                        int CBookingId=sc.nextInt();
                        sc.nextLine(); 
                        boolean f=ser.cancelBooking(CBookingId);
                        if (!f) 
                        {
                            System.out.println("Booking cancellation failed.");
                        }
                    } 
                    catch(BookingNotFoundException e)
                    {
                        System.out.println(e.getMessage());
                    } 
                    catch(Exception e) 
                    {
                        System.out.println(e.getMessage());
                    }
                    break;


                case 8:
                	System.out.println("You have decided to ALLOCATE Driver: ");
                    System.out.print("Enter Trip ID: ");
                    int ADTripId= sc.nextInt();
                    System.out.print("Enter Driver ID: ");
                    int driverId= sc.nextInt();
                    ser.allocateDriver(driverId,ADTripId);
                    break;

                case 9:
                	System.out.println("You have decided to DEALLOCATE Driver: ");
                    System.out.print("Enter Trip ID to Deallocate Driver: ");
                    int DDTripId= sc.nextInt();
                    ser.deallocateDriver(DDTripId);
                    break;

                case 10:
                	System.out.println("You have decided to View Bookings BY Passenger ID! ");
                    System.out.print("Enter Passenger ID: ");
                    int BPassengerId= sc.nextInt();
                    List<Booking> bookingsByPassenger= ser.getBookingsByPassenger(BPassengerId);
                    if(bookingsByPassenger.isEmpty()) 
                    {
                        System.out.println("No bookings found");
                    }
                    else 
                    {
                        for(Booking b:bookingsByPassenger) 
                        {
                            System.out.println(b);
                        }
                    }
                    break;

                case 11:
                	System.out.println("You have decided to View Bookings BY Trip ID! ");
                    System.out.print("Enter Trip ID: ");
                    int BoTripId = sc.nextInt();
                    List<Booking> bookings= ser.getBookingsByTrip(BoTripId);
                    if(bookings.isEmpty())
                    {
                        System.out.println("No bookings found");
                    }
                    else 
                    {
                        for (Booking b:bookings)
                        {
                            System.out.println(b);
                        }
                    }
                    break;

                case 12:
                	System.out.println("You have decided to View Available Drivers! ");
                    List<Drivers> availableDrivers= ser.getAvailableDrivers();
                    if(availableDrivers.isEmpty())
                    {
                        System.out.println("All drivers are currently allocated to trips.");
                    } 
                    else
                    {
                        System.out.println("Available Drivers:");
                        for(Drivers d:availableDrivers) 
                        {
                            System.out.println("Driver ID: "+d.getDriverID());
                        }
                    }
                    break;

                case 13:
                    System.out.println("Exiting Transport Management System. Thank you!");
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
                    break;
            }

        }while(c!=13);
        sc.close();
    }
}
