package Junit_testcases;
import dao.*;
import Model.*;
import myexceptions.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class testcases 
{

	@Test
	 
	public void testAllocateDriver() 
	{
	    TransportManagementService ser=new TransportManagementServiceImpl();
	    boolean t=ser.allocateDriver(1,2);
	    assertTrue(t);
	}
	@Test
	 
	public void testAddVehicle() 
	{
	    TransportManagementService ser=new TransportManagementServiceImpl();
	    Vehicle v=new Vehicle("m900",800,"Bus","Available");
	    boolean t=ser.addVehicle(v);
	    assertTrue(t);
	}

	@Test
	 
	public void testBookTrip() 
	{
	    TransportManagementService ser=new TransportManagementServiceImpl();
	    boolean t=ser.bookTrip(1, 1, "2025-04-14");
	    assertTrue(t);
	}
	
	@Test
	
	public void testVehicleNotFoundExceptionThrownUpdate() 
	{
	    TransportManagementService ser=new TransportManagementServiceImpl();
	    Vehicle v= new Vehicle(90, "m12", 1000, "bus", "Available");
	    assertThrows(VehicleNotFoundException.class,()->
	    {
	        ser.updateVehicle(v); 
	    });
	}
	
	@Test
	
	public void testVehicleNotFoundExceptionThrownDelete()
	{
	    TransportManagementService ser= new TransportManagementServiceImpl();
	    assertThrows(VehicleNotFoundException.class, () -> 
	    {
	        ser.deleteVehicle(100);
	    });
	}

	@Test
	
    public void testCancelBookingThrowsBookingNotFoundException()
	{
        TransportManagementService ser=new TransportManagementServiceImpl();
        assertThrows(BookingNotFoundException.class, () -> 
        {
            ser.cancelBooking(100);
        });
    }




}
