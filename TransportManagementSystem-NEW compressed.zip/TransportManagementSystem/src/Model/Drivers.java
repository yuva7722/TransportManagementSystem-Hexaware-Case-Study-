package Model;

public class Drivers {
    private int driverID;
    private int tripID;

    public Drivers() {}

    public Drivers(int driverID, int tripID) {
        this.driverID = driverID;
        this.tripID = tripID;
    }

    public int getDriverID() {
        return driverID;
    }

    public void setDriverID(int driverID) {
        this.driverID = driverID;
    }

    public int getTripID() {
        return tripID;
    }

    public void setTripID(int tripID) {
        this.tripID = tripID;
    }

    @Override
    public String toString() {
        return "Driver{" + "driverID=" + driverID + ", tripID=" + tripID +'}';
    }
}
