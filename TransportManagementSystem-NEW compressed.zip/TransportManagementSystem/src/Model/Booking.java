package Model;



public class Booking
{

	private int bookingID;
	private int tripID;
	private int passengerID;
	private String bookingDate;
	private String status;

    public Booking() {

    }

    public Booking(int bookingID, int tripID, int passengerID, String bookingDate, String status) 
    {
        
        this.bookingID = bookingID;
        this.tripID = tripID;
        this.passengerID = passengerID;
        this.bookingDate = bookingDate;
        this.status = status;
    }

    public int getBookingID() {
        return bookingID;
    }

    public void setBookingID(int bookingID) {
        this.bookingID = bookingID;
    }

    public int getTripID() {
        return tripID;
    }

    public void setTripID(int tripID) {
        this.tripID = tripID;
    }

    public int getPassengerID() {
        return passengerID;
    }

    public void setPassengerID(int passengerID) {
        this.passengerID = passengerID;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String string) {
        this.bookingDate = string;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Booking [bookingID=" + bookingID + ", tripID=" + tripID + ", passengerID=" + passengerID +
               ", bookingDate=" + bookingDate + ", status=" + status + "]";
    }
}
